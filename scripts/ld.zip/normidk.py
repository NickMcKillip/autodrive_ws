#!/usr/bin/env python
# coding: utf-8
import numpy as np
import cv2

#calib file
file = open("kcalib" + ".txt")

#input image to overlay

directory = 'fl' + '/'
image = cv2.imread(directory + "image.png",-1)
print image.shape
#input size
image_w = 799;
image_h = 799;

for line in file:
    data = line.split()
    if data[0] == "Tr_velo_to_cam:":
        velo_calib = np.array([data[1:]], dtype='float32').reshape(3,4)
    elif data[0] == "P2:":
        p2 = np.array([data[1:]], dtype='float32').reshape(3,4)
    elif data[0] == "R0_rect:":
        R0_rect2 = np.array([data[1:]], dtype='float32').reshape(3,3)
    elif data[0] == "P3:":
        p43 = np.array([data[1:]], dtype='float32').reshape(3,4)
#p2=p3



Tr_velo_to_cam = np.eye(4)
Tr_velo_to_cam[0:3, :] = velo_calib
Tr_velo_to_cam
R0_rect = np.eye(4)
#R0_rect[0:3,0:3] = R0_rect2 
point_cloud = np.load(directory + "input.npy")
point_cloud = point_cloud[point_cloud[:, 0] > 0, :]
# remove points that are located too far away from the camera:

#50 as opposed to 80 from kitti
point_cloud = point_cloud[point_cloud[:, 0] < 40, :]
point_cloud_xyz = point_cloud[:, 0:3]
point_cloud_xyz_hom = np.ones((point_cloud.shape[0], 4))
point_cloud_xyz_hom[:, 0:3] = point_cloud[:, 0:3] # (point_cloud_xyz_hom has shape (num_points, 4))

# project the points onto the image plane (homogeneous coords):
img_points_hom = np.dot(p2, np.dot(R0_rect, np.dot(Tr_velo_to_cam, point_cloud_xyz_hom.T))).T # (point_cloud_xyz_hom.T has shape (4, num_points))
# normalize:
img_points = np.zeros((img_points_hom.shape[0], 2))
img_points[:, 0] = img_points_hom[:, 0]/img_points_hom[:, 2]
img_points[:, 1] = img_points_hom[:, 1]/img_points_hom[:, 2]

# transform the points into (rectified) camera coordinates:
point_cloud_xyz_camera_hom = np.dot(R0_rect, np.dot(Tr_velo_to_cam, point_cloud_xyz_hom.T)).T # (point_cloud_xyz_hom.T has shape (4, num_points))
# normalize:
point_cloud_xyz_camera = np.zeros((point_cloud_xyz_camera_hom.shape[0], 3))
point_cloud_xyz_camera[:, 0] = point_cloud_xyz_camera_hom[:, 0]/point_cloud_xyz_camera_hom[:, 3]
point_cloud_xyz_camera[:, 1] = point_cloud_xyz_camera_hom[:, 1]/point_cloud_xyz_camera_hom[:, 3]
point_cloud_xyz_camera[:, 2] = point_cloud_xyz_camera_hom[:, 2]/point_cloud_xyz_camera_hom[:, 3]

point_cloud_camera = point_cloud
point_cloud_camera[:, 0:3] = point_cloud_xyz_camera

bbox = np.zeros((4,2))
box = np.load(directory + "bbox.npy")
print box
bbox[0,0]=box[0]/2.56#x
bbox[0,1]=box[1]/2.56#y-20#topleft
bbox[1,0]=box[2]/2.56#x+60
bbox[2,1]=box[3]/2.56#y+30#bottomright

# img = cv2.imread(self.img_dir + img_id + ".png", -1)
# img_with_bboxes = draw_2d_polys(img, [label_2D])
# cv2.imwrite("test.png", img_with_bboxes)

########################################################################
# frustum:
########################################################################
u_min = bbox[0, 0] # (left)
u_max = bbox[1, 0] # (rigth)
v_min = bbox[0, 1] # (top)
v_max = bbox[2, 1] # (bottom)

# expand the 2D bbox slightly:
u_min_expanded = u_min#*1.1#- (u_max-u_min)*.002
u_max_expanded = u_max#*.9#+ (u_max-u_min)*0.01
v_min_expanded = v_min#*1.1#- (v_max-v_min)*0.01
v_max_expanded = v_max#*.9#*#+ (v_max-v_min)*0.01
input_2Dbbox = np.array([u_min_expanded, u_max_expanded, v_min_expanded, v_max_expanded])

row_mask = np.logical_and(
            np.logical_and(img_points[:, 0] >= u_min_expanded,
                           img_points[:, 0] <= u_max_expanded),
            np.logical_and(img_points[:, 1] >= v_min_expanded,
                           img_points[:, 1] <= v_max_expanded))

frustum_point_cloud_xyz = point_cloud_xyz[row_mask, :] # (needed only for visualization)
print frustum_point_cloud_xyz,"xyzz", frustum_point_cloud_xyz.shape
frustum_point_cloud = point_cloud[row_mask, :]
frustum_point_cloud_xyz_camera = point_cloud_xyz_camera[row_mask, :]
frustum_point_cloud_camera = point_cloud_camera[row_mask, :]

if frustum_point_cloud.shape[0] == 0:
    print (img_id)
    print (frustum_point_cloud.shape)

# randomly sample 1024 points in the frustum point cloud:
if frustum_point_cloud.shape[0] < 1024:
    row_idx = np.random.choice(frustum_point_cloud.shape[0], 1024, replace=True)
else:
    row_idx = np.random.choice(frustum_point_cloud.shape[0], 1024, replace=False)
frustum_point_cloud_xyz = frustum_point_cloud_xyz[row_idx, :]
frustum_point_cloud = frustum_point_cloud[row_idx, :]
frustum_point_cloud_xyz_camera = frustum_point_cloud_xyz_camera[row_idx, :]
frustum_point_cloud_camera = frustum_point_cloud_camera[row_idx, :]
# (the frustum point cloud now has exactly 1024 points)

########################################################################
# InstanceSeg ground truth:
########################################################################

u_center = u_min_expanded + (u_max_expanded - u_min_expanded)/2.0
v_center = v_min_expanded + (v_max_expanded - v_min_expanded)/2.0
center_img_point_hom = np.array([u_center, v_center, 1])
# (more than one 3D point is projected onto the center image point, i.e,
# the linear system of equations is under-determined and has inf number
# of solutions. By using the pseudo-inverse, we obtain the least-norm sol)

# get a point (the least-norm sol.) that projects onto the center image point, in hom. coords:
P2_pseudo_inverse = np.linalg.pinv(p2) # (shape: (4, 3)) (P2 has shape (3, 4))
point_hom = np.dot(P2_pseudo_inverse, center_img_point_hom)
# hom --> normal coords:
point = np.array(([point_hom[0]/point_hom[3], point_hom[1]/point_hom[3], point_hom[2]/point_hom[3]]))

# if the point is behind the camera, switch to the mirror point in front of the camera:
if point[2] < 0:
    point[0] = -point[0]
    point[2] = -point[2]
print point,"pt" 
# compute the angle of the point in the x-z plane: ((rectified) camera coords)
frustum_angle = np.arctan2(point[0], point[2]) # (np.arctan2(x, z)) # (frustum_angle = 0: frustum is centered)

# rotation_matrix to rotate points frustum_angle around the y axis (counter-clockwise):
frustum_R = np.asarray([[np.cos(frustum_angle), 0, -np.sin(frustum_angle)],
                   [0, 1, 0],
                   [np.sin(frustum_angle), 0, np.cos(frustum_angle)]],
                   dtype='float32')

# rotate the frustum point cloud to center it:
centered_frustum_point_cloud_xyz_camera = np.dot(frustum_R, frustum_point_cloud_xyz_camera.T).T
print frustum_point_cloud_camera,"2"
#minz = min(frustum_point_cloud_xyz[:,2])-5
minx = np.mean(frustum_point_cloud_xyz_camera[:,0])

ind = np.argmin((frustum_point_cloud_xyz[:,2]))
minpoint = frustum_point_cloud_xyz[ind,:]
print minpoint,"minpoint"
print np.mean(frustum_point_cloud_xyz,axis=0),"mean"
a = np.min(frustum_point_cloud_xyz,axis=0)
import math 
print a
mindist = math.sqrt(a[0]**2 + a[1]**2 + a[2]**2)
print mindist,"min dist formula"



centered_frustum_point_cloud_xyz_camera2 = np.dot(frustum_R, center_img_point_hom.T).T
print frustum_point_cloud_xyz_camera.shape, frustum_point_cloud_xyz_camera.T.shape, "TT"
print centered_frustum_point_cloud_xyz_camera2
# subtract the centered frustum train xyz mean:

centered_frustum_point_cloud_camera = frustum_point_cloud_camera
centered_frustum_point_cloud_camera[:, 0:3] = centered_frustum_point_cloud_xyz_camera

idk = np.dot(p2, np.dot(R0_rect, np.dot(Tr_velo_to_cam, centered_frustum_point_cloud_camera.T))).T
ftest = img_points[row_mask,:]
img_points = img_points[img_points[:, 0] > 0, :]
img_points = img_points[img_points[:, 0] < image_h, :]
img_points = img_points[img_points[:, 1] > 0, :]
img_points = img_points[img_points[:, 1] < image_w, :]
img_points = img_points.astype(int)
ftest = ftest.astype(int)

for i in range(1,len(img_points)):
  #color 
  image[img_points[i][1],img_points[i][0],0] = 0
  image[img_points[i][1],img_points[i][0],1] = 255
  image[img_points[i][1],img_points[i][0],2] = 0

for i in range(1,len(ftest)):
  #color 
  image[ftest[i][1],ftest[i][0],0] = 0
  image[ftest[i][1],ftest[i][0],1] = 0
  image[ftest[i][1],ftest[i][0],2] = 255
cv2.imwrite(directory + "outputimage2.png",image)  
